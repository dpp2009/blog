window.onload=init;
function init(){
	var dpp=document.getElementById("nav").childNodes[1].childNodes;
	var len=dpp.length;
	var v1=location.href;
	var len3=v1.length;
	var v2=v1.substring(0,len3-1);//去除链接字符窜的最后一个字符

	for(var i=1;i<len;i+=2){
		var cl=dpp[i].childNodes[0].href;
		if(v1==cl || v2==cl){
			dpp[i].className="current2";
		}else{
			dpp[i].className="current";
		}
	}

	

}
