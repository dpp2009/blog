<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footerbar">
	Design By blogbus | Theme By <a href="http://onelose.com" title="迷茫者博客">迷茫者</a> | Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> |  
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> | <?php echo $footer_info; ?>
	<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
<script>prettyPrint();</script>

<div id="returnhome"><a href="#"><img src="<?php echo TEMPLATE_URL; ?>images/home.png" title="返回" alt="header" id="returnhome_img"></a></div>

</body>
</html>