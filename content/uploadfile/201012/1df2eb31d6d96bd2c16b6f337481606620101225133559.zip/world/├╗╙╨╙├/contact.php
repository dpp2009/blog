<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/headtop.php'); ?>
<?php
/*
Template Name: contact
*/
?>
<div id="container"> 
<div id="content"> 
<h2 class="page-title">联系方式</h2> 
<div id="post"> 
	<div class="entry-content"> 
	
平时事多<br /> 
但是在网时间不少<br /> 
QQ、Email 随便哪个都可以<br /> 
有事没事都联系我，交个朋友也是可以的<br /> 
放弃从前的所有，没有什么事情做不到，就看你想不想去做。</p>
<h3>这是我的唯一 QQ：</h3> 
<p><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=137115540&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:137115540:41" alt="点击这里给我发消息" title="点击这里给我发消息"></a></p> 
<h3>下面就是我的邮箱：</h3> 
<p><img class="alignnone" src="http://www.bianworld.com/plus/images/gmail.gif" alt="" width="200" height="20" /></p> 
<div id="mblog"> 
&nbsp;</p> 
<h3>我的微博帐号：</h3> 
<p>下面是一些我主要用的微博帐号，你也可以收听它们，它们都会同步更新的！但是 sina微博 除外，因为我还没有找到同步到新浪的最方便的办法。</p> 
<p><a target="_blank" href="http://t.qq.com/ziqiang">QQ微博</a>  | <a target="_blank" href="http://t.sina.com.cn/ziqiangen">新浪微博</a>  |  <a target="_blank" href="http://digu.com/ziqiang">嘀咕</a> 
</div> 
		</div> 
</div><!-- .post --> 
 
<div id="hot_tab_div"> 
		<div id="hot_tab_title">[ 彼岸世界还有更多精彩 ]</div> 
			<div id="hot_top" class="rbox_t"></div> 
			<div id="hot_center" class="rbox_c"> 
<?php include (TEMPLATEPATH . '/hot_tab.php'); ?>
			</div><!--rbox_c--> 
			<div id="hot_bottom"  class="rbox_b"></div> 
		</div><!--hot_tab_div--> 

</div><!-- #content --> 
</div><!-- #container --> 
	<?php include (TEMPLATEPATH . '/sidebar_2.php'); ?>
<?php get_footer(); ?>