<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/headtop.php'); ?>
<?php
/*
Template Name: building
*/
?>
<div id="content"> 
				<div class="page-title">本页面正在紧急制作中…… </div> 
				<div style="text-align:center;width:100%"> 
						 ╮(╯_╰)╭<br/><br/><br/> 
						<a href="<?php echo home_url( '/' ) ?>">[ 回首页逛逛吧 ]</a> 
				</div> 
	</div><!-- #content --> 
	
	<?php get_sidebar(); ?>
	</div><!-- #container -->
	
	<?php get_footer(); ?>