<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/headtop.php'); ?>
<?php
/*
Template Name: Guestbook
*/
?>
<div id="container"> 
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="content"> 
<h2 class="page-title">留下足迹</h2> 
<div id="post-481"> 
	<div class="entry-content"> 
	<p><img class="aligncenter" title="在<?php bloginfo( 'name' ); ?>留下你要说的话" src="<?php bloginfo( 'name' ); ?>plus/images/pleasewritetalk.jpg" alt="在彼岸世界里留下你要说的话" width="500" height="333" /></p> 
<p style="text-align: center;">不知不觉间，岁月的纹路就爬上了曾经年轻的面庞。有条不紊的时光中，失去韵律和色彩。<br />对于现在来说，只能回忆，回忆当初... 回忆曾经...</p> 


		</div> 
</div><!-- .post --> 
<?php comments_template(); ?>
</div><!-- #content -->
<?php endwhile; ?>

<?php endif; ?> 
<?php include (TEMPLATEPATH . '/sidebar_2.php'); ?>
</div><!-- #container --> 

	<?php get_footer(); ?>