<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/headtop.php'); ?>
<?php
/*
Template Name: about
*/
?>
<div id="container"> 
<div id="content"> 
<h2 class="page-title">关于本站</h2> 
<div id="post-489"> 
	<div class="entry-content"> 
	<p style="text-align: center;"><img class="alignnone" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" src="<?php echo home_url( '/' ) ?>plus/images/aboutme.jpg" /></p> 
<h3>前言</h3> 
<p>这个世界好吵，好吵，拥挤的人群，嘈杂的声音，不断在我的耳边回荡。我缓缓的走进水里，想让自己变得清醒，想在静止的水里安静停留。能听见沉默时间转动的秒针，那是来自于安静的世界。闭上眼睛：蓝天、白云；都飘入了眼里。站在一望无际高过自己的草地里，不会感到美丽。只会让自己变得更加得迷惘，仿佛走进一个迷宫，找不到终点，也回不到起点。
</p> 
<h3>关于我：</h3> 
<p>昵称：子强，没有什么特殊的含义。爸妈给我起的，感觉很好，很喜欢。<br /> 典型的90后，现在来说90后一般都代表了非主流，但是我例外。17岁开始踏入社会，虽然不是一帆风顺，但是也没有经历过什么大风大浪。<br />
对于现在来说，在互联网上喜欢一个人做事，可能你们会说我没有团队精神，无所谓。<br />
计算机方面接触了很多东西，自认为计算机方面我还有百分之一的天分。以后会指这个吃一辈子饭的，但现在看来，好象是有点跟不上脚步了，信息时代，进步太快了，新生事物太多太多，要学的东西也太多太多。不止要学习计算机，还要学习如何做人、做事。<br />
2010年放下了全部、所有。重新"做人"，包括 QQ号码、Eamil、手机号…… 全都换成新的，开始接收新事物。但是好象貌似不是很顺利。希望以后……  继续努力吧！</p>

<h3>关于彼岸世界：</h3> 
<p>彼岸世界，领导人：子强，原为一个神秘组织，简称：BWD&nbsp;&nbsp;活动极为保密，自建立至2009年初只在互联网上出现过一次，曾经引起业界巨大轰动，后归隐，至此互联网上所有有关 BWD&nbsp;&nbsp;组织相关信息全部删除。所有成员要求发誓严守组织所有信息。曾经核心成员如今也不知去向。<br />
现如今的彼岸世界已经进化到一个网站了，是一个可以上见天下见地的合法网站。主要发一些 关于 子强 的一些信息，比如：一些学习资料、经典文章、个人语录、生活随笔等。<br />
彼岸世界web 纯属是个人爱好，建于  2009 年，至今已经改版多次，域名换过多个，无一满意，希望该版本可以长久下去。
本站不追求排名、PR值、收录……  只为给自己的生活做个总结。多年之后还可以回头看一看当年彼岸世界。
</p> 
<h3>结束语</h3> 
 
		</div> 
</div><!-- .post --> 
 
<div id="hot_tab_div"> 
		<div id="hot_tab_title">[ 还有更多精彩 ]</div> 
			<div id="hot_top" class="rbox_t"></div> 
			<div id="hot_center" class="rbox_c"> 
						<?php include (TEMPLATEPATH . '/hot_tab.php'); ?>
			</div><!--rbox_c--> 
			<div id="hot_bottom"  class="rbox_b"></div> 
		</div><!--hot_tab_div--> 

</div><!-- #content --> 
</div><!-- #container --> 
	<?php include (TEMPLATEPATH . '/sidebar_2.php'); ?>
	<?php get_footer(); ?>