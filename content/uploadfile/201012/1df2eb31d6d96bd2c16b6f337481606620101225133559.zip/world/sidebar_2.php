		<div id="sidebar"> 
		<ul> 
				
			<?php if (get_option('world_if_ad_singlesidebar') == '1') { ?>
							<li class="widget"> 
				<div id="widget_top_ad"> 
					<ul> 
					<?php echo get_option('world_ad_singlesidebar'); ?>
					</ul> 
					<a id="widget_buy_ad" style="float:right;padding:0 17px 0 5px;color:#cccccc" href="http://www.bianworld.com/contact">联系购买广告位</a> 
				</div> 
			</li> 
 <?php } else { ?><?php } ?>
			
		<?php if (get_option('world_if_digu') == '1') { ?>
		<li class="widget"> 
				<div class="widget_t"> </div> 
				<div class="widget_c"> 
						<div class="fanfou_header">
						<a target="_blank" href="<?php echo get_option('world_digu_avatar_link'); ?>"><img class="fanfou_avatar"  src="<?php echo get_option('world_digu_avatar'); ?>" /></a>			
						<span class="fanfou_name"><?php echo get_option('world_digu_title'); ?></span><br/><?php echo get_option('world_digu_other_title'); ?><br/> <span class="fanfou_t"><a target="_blank"  href="<?php echo get_option('world_digu_other_link1'); ?>" ><?php echo get_option('world_digu_other_title1'); ?></a> | <a target="_blank" href="<?php echo get_option('world_digu_other_link2'); ?>"><?php echo get_option('world_digu_other_title2'); ?></a>  |  <a target="_blank" href="<?php echo get_option('world_digu_other_link3'); ?>"><?php echo get_option('world_digu_other_title3'); ?></a></span></div>
						<div id="twitter_div"> 
								<ul id="twitter_update_list"> 
						<!--mblog-for-ips-->
				<?php echo get_option('world_digu_jscode'); ?>
</ul></div> 
				</div> 
				<div class="widget_b"></div> 
			</li> 
			<?php } else { ?><?php } ?>
 <li class="widget"> 
				<div class="widget_t"> </div> 
				<div class="widget_c"> 
						<div class="item_title">本月不被践踏最不舒服的文章：<br/><span>Most Read Posts</span></div> 
						<ul class="most_view"> 
							 <?php get_most_viewed('post', 15, 30, true, true); ?>
					    </ul> 
				</div> 
				<div class="widget_b"></div> 
			</li> 
 <li class="widget"> 
				<div class="widget_t"></div> 
				<div class="widget_c"> 
						<div class="item_title">站内搜索：<br/><span>WordPress Search</span></div> 
							<div class="widget_content"> 
				<?php include (TEMPLATEPATH . '/searchform.php'); ?>
						</div> 
				</div> 
				<div class="widget_b"></div> 
			</li> 
  <li class="widget"> 
				<div class="widget_t"></div> 
				<div class="widget_c"> 
					<div class="item_title">宝藏<br/><span>Categorys</span></div> 
					<div class="widget_cat"> 
						<ul><?php wp_list_categories("title_li=&orderby=id&hierarchical=0&show_count=0"); ?></ul> 
				</div></div> 
				<div class="widget_b"></div> 
			</li> 
  <li class="widget"> 
				<div class="widget_t"> </div> 
				<div class="widget_c"> 
						<div class="item_title">随便找点东西来看看：<br/><span>Random Posts</span></div> 
						<ul class="randomposts"> 
<?php 
$randposts = $wpdb->get_results('SELECT p.ID, p.post_title, rand()*p1.id AS o_id FROM ' . 
$wpdb->posts . ' AS p JOIN ( SELECT MAX(ID) AS id FROM ' 
. $wpdb->posts . ' WHERE post_type="post" AND post_status="publish") AS p1 WHERE p.post_type="post"  
AND p.post_status="publish" ORDER BY o_id LIMIT 15');                
foreach($randposts as $randpost) 
{                    
echo('<li><a href="' . get_permalink($randpost->ID) 
. '">' 
. $randpost->post_title . '</a></li>');   
             }      
			 ?>		
			 </ul> 
				</div> 
				<div class="widget_b"></div> 
			</li> 
 
 			 <?php if(get_theme_mod('showads') == 'Yes') { ?>
 	 <li class="widget"> 
				<div class="widget_t"></div> 
				<div class="widget_c"> 
					<div class="item_title">值得推荐一下<br/><span>Recommend Products</span></div> 
					<div class="widget_content"> 
				<center><?php echo stripslashes(get_theme_mod('ads')); ?></center>
					</div> 
				</div> 
				<div class="widget_b"></div> 
			</li>  
	 <?php } else { ?><?php } ?> 
			
			<li class="widget"> 
				<div class="widget_t"></div> 
				<div class="widget_c"> 
					<div class="item_title">某人华丽地飘过的同时说：<br/><span>Recent Comment</span></div> 
					<div style="width:100%;text-align:center">已被留下 <span style="font-size:14px;color:red"><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?></span> 个脚印了</div><ul id="recentcomments">
	<?php
global $wpdb;
$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url,comment_author_email, SUBSTRING(comment_content,1,80) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND user_id='0' ORDER BY comment_date_gmt DESC LIMIT 8";
$comments = $wpdb->get_results($sql);

foreach ($comments as $comment) {
$output .= "\n<li><div class=\"rc_avatar\">" .get_avatar(get_comment_author_email(), 32)."</a></div><div class=\"rc_comment\"><a href=\"" . get_permalink($comment->ID) ."#comment-" . $comment->comment_ID . "\" title=\"" .$comment->post_title ."\"> ".strip_tags($comment->comment_author)." 说</a>:<br/>" . strip_tags($comment->com_excerpt)."..</div></li>";
}
$output = convert_smilies($output);
echo $output;
?></ul> 
				</div> 
				<div class="widget_b"></div> 
			</li> 
 
			<li class="widget"> 
				<div class="widget_t"></div> 
				<div class="widget_c"> 
					<div class="item_title">标签云集<br/><span>Tag Cloud</span></div> 
					<div class="widget_content"> 
					<div id="sidebar_tagcloud"><?php wp_tag_cloud('smallest=9&largest=9'); ?>				
					</div><div class="clear"></div>					</div> 
				</div> 
				<div class="widget_b"></div> 
			</li> 
				<li class="widget"> 
				<div class="widget_t"></div> 
				<div class="widget_c"> 
					<div class="item_title">未知大陆<br/><span>Unknow</span></div> 
					<div class="widget_content"> 
							<center></center> 
					</div> 
				</div> 
				<div class="widget_b"></div> 
			</li> 
 
		</ul> 
	</div><!-- #primary .sidebar -->
	<div class="clear"></div> 