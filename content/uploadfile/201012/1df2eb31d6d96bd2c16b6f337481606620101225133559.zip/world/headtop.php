<div id="crumb"> 
	<span>你的位置： </span>
				 <?php /* If this is a category archive */ if (is_home()) { ?>
                <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span>	  <?php if( $paged == '' ) $thispageis = ''; else $thispageis = '<span>第'.$paged.'页</span>'; echo $thispageis; ?>
          <?php /* If this is a tag archive */ } elseif(is_category()) { ?>
		  <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a><span class="gt"></span> <?php single_cat_title('') ?> 
          <?php /* If this is a search result */ } elseif (is_search()) { ?>
                <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a><span class="gt"></span> <?php echo $s; ?>
          <?php /* If this is a tag archive */ } elseif(is_tag()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a><span class="gt"></span> <?php single_tag_title(); ?>
          <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> <?php the_time('Y, F jS'); ?> 时间内的文章
          <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> <?php the_time('Y, F'); ?> 时间内的文章
          <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> <?php the_time('Y'); ?> 时间内的文章
          <?php /* If this is an author archive */ } elseif (is_author()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> 作者文章
          <?php /* If this is a single page */ } elseif (is_single()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> <?php the_category(', ') ?> <span class="gt"> </span> 阅读文章
          <?php /* If this is a page */ } elseif (is_page()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> <?php the_title(); ?>
          <?php /* If this is a 404 error page */ } elseif (is_404()) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> 404 错误
          <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
                 <a href="<?php echo get_settings('home'); ?>"><?php bloginfo( 'name' ); ?></a> <span class="gt"></span> 存档
          <?php } ?>
		
 <?php if (get_option('world_if_ad_topad') == '1') { ?>
 <span class="crumb_ad"><a rel="nofollow" target="_blank" href="<?php echo get_option('world_ad_topbanner_link'); ?>"><?php echo get_option('world_ad_topbanner'); ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
		<a rel="nofollow" target="_blank" href="<?php echo get_option('world_ad_topbanner_link2'); ?>"><?php echo get_option('world_ad_topbanner2'); ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
		 <a rel="nofollow" target="_blank" href="<?php echo get_option('world_ad_topbanner_link3'); ?>"><?php echo get_option('world_ad_topbanner3'); ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
		 </span>
			 <?php } else { ?>
		 <?php } ?>
</div> 