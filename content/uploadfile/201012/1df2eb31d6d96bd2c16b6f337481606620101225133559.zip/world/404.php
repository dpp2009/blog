	<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/headtop.php'); ?>
	<div id="container"> 
		<div id="content"> 
             <div id="post" class="post error404"> 
				<h2 class="entry-title">对不起，你要访问的页面不存在或已经被删除！</h2> 
				<div class="entry-content"> 
					<br/> 
					<p> 
					<a href="<?php echo home_url( '/' ) ?>"><img alt="返回首页" title="返回首页" src="<?php bloginfo('template_directory'); ?>/images/err404.gif" /></a> 
					</p> 
					<p> 
					你要访问的页面不存在或已被删除，或者你访问的地址不正确，你可以尝试搜索想要看的内容：
					</p> 
					
					<div class="page-search"> 
						<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</div> 
					<style>.search-goog form{display:none;}.search-goog{color:#FFF}</style> 
				</div> <!-- entry-content --> 
			</div><!-- .post --> 
 
			<div id="hot_tab_div"> 
			<div id="hot_tab_title">[ 还有更多精彩 ]</div> 
									<div id="hot_top" class="rbox_t"></div> 
									<div id="hot_center" class="rbox_c"> 
									<?php include (TEMPLATEPATH . '/hot_tab.php'); ?>
									</div><!--rbox_c--> 
									<div id="hot_bottom"  class="rbox_b"></div> 
			</div><!--hot_tab_div--> 
 
		</div><!-- #content --> 
	</div><!-- #container --> 
		<?php include (TEMPLATEPATH . '/sidebar_2.php'); ?>
	<?php get_footer(); ?>