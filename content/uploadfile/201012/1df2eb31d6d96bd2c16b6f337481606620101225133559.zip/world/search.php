<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/headtop.php'); ?>
<?php
/*
Template Name: search
*/
?>
	<div id="container"> 
		<div id="content"> 
					<div style="text-align:center;width:100%"> 
								<div class="page-search"> 
										<?php include (TEMPLATEPATH . '/searchform.php'); ?>
								</div> 
									<div class="page-title"> 
								正在显示搜索结果								</div> 
							
								<div id="cse-search-results"></div> 
					</div><!-- text-align:center--> 
 <div id="hot_tab_div"> 
					<div id="hot_tab_title">[ 更多精彩 ]</div> 
											<div id="hot_top" class="rbox_t"></div> 
											<div id="hot_center" class="rbox_c"> 
								<?php include (TEMPLATEPATH . '/hot_tab.php'); ?>
						</div><!--  #rbox_c--> 
											<div id="hot_bottom"  class="rbox_b"></div> 
					</div><!--hot_tab_div--> 
 
 <div id="cse-search-results"></div>
<script type="text/javascript">
  var googleSearchIframeName = "cse-search-results";
  var googleSearchFormName = "cse-search-box";
  var googleSearchFrameWidth = 680;
  var googleSearchDomain = "www.google.com";
  var googleSearchPath = "/cse";
</script>
<script type="text/javascript" src="http://www.google.com/afsonline/show_afs_search.js"></script>
</div><!-- #content --> 
	<?php include (TEMPLATEPATH . '/sidebar_2.php'); ?></div><!-- #container --> 
 	<?php get_footer(); ?>