	<?php get_header(); ?>
	<?php include (TEMPLATEPATH . '/headtop.php'); ?>
	<div id="container"> 
		<div id="content"> 
<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
					<div id="post"> 
				<!-- google_ad_section_start --> 
				<h2 class="entry-title"><?php the_title(); ?></h2> 
				[ <?php the_category(' | ') ?> ]&nbsp;&nbsp;<?php # single.php not all
     $from = get_post_meta($post->ID, 'from', true); 
     if(!empty($from)){
        echo '[ 本文来源'."$from ]" ; 
                      }
//这段代码应该写在您使用的主题的single.php文件中
?>
									<center> 
					<div style="margin:10px 0 25px 0"> 
							<!-- 文章页顶部 -->
					</div> 
					</center> 
				<div class="entry-banner"></div>	
						<div class="entry-content"> 
						 <?php the_content(); ?>
						<!-- google_ad_section_end --> 
									</div> 
				<div style="margin-top:20px"> 
					<div style="float:left"> 
						<!--script ad  type="text/javascript"> /*[iPs] 文章页左下方 336x280*/ var cpro_id = 'u24684';</script--> 
						<!--script ad  type="text/javascript" src="http://cpro.baidu.com/cpro/ui/c.js"></script--> 
											</div> 
					<div style="float:left"> 
				<!--script ad   script type='text/javascript'>BAIDU_CLB_fillSlot('37964');</script--> 
					</div> 
				</div> 
				<script language="javascript">ShareButtons();</script>
				<div class="entry-meta" style="clear:both"> 
							<ul> 
								<li>属于分类：<?php the_category(' | ') ?></li> 
								<li>本文标签：<?php the_tags('' , ' , ' , ''); ?></li>								  <li>流行热度：<span id="post_view_count">超过 <span><?php if(function_exists('the_views')) { the_views(); } ?></span> 人围观</span></li>
							   <li>开荒日期：<?php bloginfo( 'name' ); ?>纪元 <?php the_time("y年m月j日 - G时h分s秒"); ?></li>
 							   <li>加载用时：加载本文共用时 <?php timer_stop(1); ?> 秒</li>
							   <li>文章链接：<a href="<?php the_permalink() ?>"><?php the_permalink() ?></a> [<a href="#" onclick="copy_code('<?php the_permalink() ?>'); return false;">复制</a>] (转载时请注明本文出处及文章链接)</li></ul> 
						<ul class="entry-relate-links"> 
								<li><span>上一篇 &gt;：</span><?php previous_post_link('<strong> </strong> %link') ?></li> 
								<li><span>下一篇 &gt;：</span><?php next_post_link('%link <strong>  </strong>') ?></li> 
							</ul>
							<div id="wumiiDisplayDiv"></div>
							<?php echo wp_get_related_posts(); ?>
	</div> 
			</div><!-- .post --> 
			<?php endwhile; ?>
<?php endif; ?>
						<div class="clear"></div>
	<?php comments_template(); ?>
	</div><!-- #content --> 	
<?php include (TEMPLATEPATH . '/sidebar_2.php'); ?>
	</div><!-- #container --> 	
		<?php get_footer(); ?>