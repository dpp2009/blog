<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/headtop.php'); ?>
	<div id="section_hot"> 
				<div id="hot_left" class="float-left"> 
						<div id="play_top" class="rbox_t"></div> 
						<div id="play_center" class="rbox_c"> 
						<div id="play">	
								<div id="play_bg"></div> 
								<div id="play_info"></div> 
								<div id="play_control"> 
										<ul> 
										<?php if (get_option('world_if_slide') == '1') { ?>
											<li><b>1</b></li>
											<?php } else { ?><?php } ?>	
											<?php if (get_option('world_if_slide2') == '1') { ?>
											<li><b>2</b></li>
											<?php } else { ?><?php } ?>
												<?php if (get_option('world_if_slide3') == '1') { ?>
											<li><b>3</b></li>
											<?php } else { ?><?php } ?>	
												<?php if (get_option('world_if_slide4') == '1') { ?>
											<li><b>4</b></li>
											<?php } else { ?><?php } ?>	
											<?php if (get_option('world_if_slide5') == '1') { ?>
											<li><b>5</b></li>
											<?php } else { ?><?php } ?>	
										</ul> 
								</div> 
 
								<div id="play_list"> 


								<?php if (get_option('world_if_slide') == '1') { ?>
								<a href="<?php echo get_option('world_slide_link'); ?>" target="_blank"> 
										<img src="<?php echo get_option('world_slide_pic_path'); ?>" title="" alt="&lt;b&gt;<?php echo get_option('world_slide'); ?>&lt;/b&gt; <?php echo get_option('world_slide_des'); ?>" /> 
									</a><?php } else { ?><?php } ?>	
	<?php if (get_option('world_if_slide2') == '1') { ?>
									<a href="<?php echo get_option('world_slide_link2'); ?>" target="_blank"> 
										<img src="<?php echo get_option('world_slide_pic_path2'); ?>" title="" alt="&lt;b&gt;<?php echo get_option('world_slide2'); ?>&lt;/b&gt; <?php echo get_option('world_slide_des2'); ?> " /> 
									</a><?php } else { ?><?php } ?>
									
										<?php if (get_option('world_if_slide3') == '1') { ?>
									<a href="<?php echo get_option('world_slide_link3'); ?>" target="_blank"> 
										<img src="<?php echo get_option('world_slide_pic_path3'); ?>" title="" alt="&lt;b&gt;<?php echo get_option('world_slide3'); ?>&lt;/b&gt; <?php echo get_option('world_slide_des3'); ?> " /> 
									</a><?php } else { ?><?php } ?>	

									
<?php if (get_option('world_if_slide4') == '1') { ?>
									<a href="<?php echo get_option('world_slide_link4'); ?>" target="_blank"> 
										<img src="<?php echo get_option('world_slide_pic_path4'); ?>" title="" alt="&lt;b&gt;<?php echo get_option('world_slide4'); ?>&lt;/b&gt; <?php echo get_option('world_slide_des4'); ?> " /> 
									</a><?php } else { ?><?php } ?>	

<?php if (get_option('world_if_slide5') == '1') { ?>
									<a href="<?php echo get_option('world_slide_link5'); ?>" target="_blank"> 
										<img src="<?php echo get_option('world_slide_pic_path5'); ?>" title="" alt="&lt;b&gt;<?php echo get_option('world_slide5'); ?>&lt;/b&gt; <?php echo get_option('world_slide_des5'); ?> " /> 
									</a><?php } else { ?><?php } ?>		
						</div> <!-- #5 -->
							</div><!--  #play  --> 
 
							<script type="text/javascript"> 
									var t = n = 0, count = $("#play_list a").size();
									$(function(){	
										$("#play_list a:not(:first-child)").hide();
										$("#play_info").html($("#play_list a:first-child").find("img").attr('alt'));
										$("#play_control li:first-child").css({"background-position":"-17px -215px"});
										$("#play_info").click(function(){window.open($("#play_list a:first-child").attr('href'), "_blank")});
										$("#play_control li").click(function() {
											var i = $(this).text() - 1;
											n = i;
											if (i >= count) return;
											$("#play_info").html($("#play_list a").eq(i).find("img").attr('alt'));
											$("#play_info").unbind().click(function(){window.open($("#play_list a").eq(i).attr('href'), "_blank")})
											$("#play_list a").filter(":visible").fadeOut(500).parent().children().eq(i).fadeIn(1000);
											$(this).css({"background-position":"-17px -215px"}).siblings().css({"background-position":"0 -215px"});
										});
										t = setInterval("showAuto()", 3500);
										$("#play").hover(function(){clearInterval(t)}, function(){t = setInterval("showAuto()", 3500);});
									})
 
									function showAuto()
									{
										n = n >= (count - 1) ? 0 : ++n;
										$("#play_control li").eq(n).trigger('click');
									}
							</script> 
				</div><!--  #play_center--> 
				<div id="play_bottom"  class="rbox_b"></div> 
				</div><!--  #hot_left--> 
				<div id="hot_right" class="float-left"> 
						<div id="hot_top" class="rbox_t"></div> 
						<div id="hot_center" class="rbox_c"> 
								<?php include (TEMPLATEPATH . '/hot_tab.php'); ?>
						</div><!--  #rbox_c--> 
						<div id="hot_bottom" class="rbox_b"></div> 
				</div><!-- #hot_right--> 
	</div> <!--  #section_hot  -->
		<?php if (get_option('world_if_tip') == '1') { ?>
		 <?php if (get_option('world_tip')) { ?><div id="tip" style="width:978px; line-height:25px; height:25px; background:#F1F7FD; text-align:center; border:1px solid #D2E8FA; margin:15px 0 -10px 0; color:#3C99C9; overflow:hidden"><?php echo get_option('world_tip'); ?></div><?php } ?>
		 <?php } else { ?>
		 <?php } ?>
		 
 <?php $my_query = new WP_Query('showposts=1');

 while ($my_query->have_posts()) : $my_query->the_post();

 $do_not_duplicate = $post->ID;?>
		<div id="section_show_post"> 
			<div class="rbox_t"></div> 
			<div class="rbox_c"> 
				<div id="show_post_entry"> 
						<div class="entry-title"> 
						<!-- google_ad_section_start --> 
						<h2><span>[ <?php the_category(' | ') ?> ]</span><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2> 
						</div> 
						<div class="entry-banner"><?php
$soContent = $post->post_content;
$soImages = '~<img [^\>]*\ />~';
preg_match_all( $soImages, $soContent, $thePics );
$allPics = count($thePics[0]);
if( $allPics > 0 ){
echo $thePics[0][0];
}
else {
echo '';//<img src="/plus/default.gif" border="0" />
}
?></div>
<div> 
								 <?php 
 if(has_excerpt()) the_excerpt();
 else
         echo mb_strimwidth(strip_tags($post->post_content),0,500,'……');
		 ?>
								<!-- google_ad_section_end --> 
								<div class="entry-meta"> 
									<span class="meta_comment"><?php comments_popup_link('发现&nbsp;0 个古生物抵达新大陆 &#187;', '发现&nbsp;1 个古生物抵达新大陆 &#187;', '发现&nbsp;% 个古生物抵达新大陆 &#187;'); ?></span> 
									<div class="meta_tags"><span id="spn">已有 <?php if(function_exists('the_views')) { the_views(); } ?> 人阅读</span><script type="text/javascript">strBatchView+=",";</script>  |  <span>开荒于<?php the_time("y年m月j日"); ?></span>  |  <?php the_tags(' ' , ' , ' , ' '); ?></span></div> 
								</div> 
						</div> 
				</div><!--show_post_entry--> 
			 <?php if (get_option('world_if_ad_navtopad') == '1') { ?>
<div id="show_post_side"> 
					<!-- 首页首篇文章AD 250x250  -->
<?php echo get_option('world_ad_navtopad'); ?>	</div> 
			<?php } else { ?><?php } ?>
<?php
$next_post = get_adjacent_post(false,'',true) ;
$prev_post = get_adjacent_post(false,'',false) ;
?>
			<a title="上一篇文章" onclick="return false;" rel="<?php echo $prev_post->ID;?>" href="#" id="post_show_link_l" style="display: none;"></a>
	<a title="下一篇文章" onclick="return false;" rel="<?php echo $next_post->ID;?>" href="#" id="post_show_link_r" style="display: none;"></a>
			</div><!--rbox_c--> 
			<div class="rbox_b"></div> 
	</div>  <!--  #section_show_post -->
	<?php endwhile; wp_reset_query();?>

		<div id="section_info"> 
			<div class="rbox_t"></div> 
			<div class="rbox_c"> 
						<div id="info_l" > 
						<div class="item_title">网站云安全中心<br/><span>Site Cloud Security Center</span></div> 
							<div id="Cloud_security"> 
								
								</div> 
								<div id="Cloud_security_other"> 
								</div> 
						</div> 
 
						<div id="info_c">  <!-- 预留搜索-->
								<div class="item_title">寻找新物种<br/><span>Search Everything</span></div> 
								<div id="index_gg_search"> 
					<?php include (TEMPLATEPATH . '/searchform.php'); ?>
								</div> 
								<!--div id="pop_search">热门搜索：</div--> 
						</div> 
 
						<div id="info_r"> 
							<div id="cat_list"> 
								<div class="item_title">分类<br/><span>Site Categories</span></div> 
								<ul><?php wp_list_categories("title_li=&orderby=id&hierarchical=0&show_count=0"); ?>
							</ul>
							</div> 
						</div> 
			</div><!--rbox_c--> 
			<div class="rbox_b"></div> 
	</div>  <!--  #section_info  -->
 
	<div id="section_post"> 
		<div id="postlist"> 
				<div class="pagenavi"> 
<span class="pagenavi_l"></span><span class="pagenavi_c"><span class="pages">新鲜热辣的文章</span>
<?php if($pagenavnum=='default'){
		if(function_exists('wp_pagenavi')){wp_pagenavi();}else{?>
		<section class="alignleft"><?php next_posts_link('&laquo; Older Entries');?></section>
    <section class="alignright"><?php previous_posts_link('Newer Entries &raquo;');?></section>
    <section class="clear"></section> 
	<?php }
	}else{pagenavitop();}?>
</span><span class="pagenavi_r"></span></div> 
         <div style="height:15px"></div> 
				<!-- google_ad_section_start --> 
<?php $limit = get_option('posts_per_page');
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
query_posts('showposts=' . $limit=10 . '&paged=' . $paged); ?>
<?php while (have_posts()) : the_post(); if( $post->ID == $do_not_duplicate )  continue;  ?>
<div class="entry"> 
							<div class="entry-head"> 
										<h2 class="entry-title"><a href="<?php the_permalink() ?>"> <?php the_title(); ?></a></h2> 
										<div class="entry-cat">[ <?php the_category(' , ') ?> ]</div> 
							</div> 
 							
		<div class="entry-banner"><?php
$soContent = $post->post_content;
$soImages = '~<img [^\>]*\ />~';
preg_match_all( $soImages, $soContent, $thePics );
$allPics = count($thePics[0]);
if( $allPics > 0 ){
echo $thePics[0][0];
}
else {
echo '';//<img src="/plus/default.gif" border="0" />
}
?></div>	
						<div class="entry-content"> 
							 <?php 
 if(has_excerpt()) the_excerpt();
 else
         echo mb_strimwidth(strip_tags($post->post_content),0,500,'……');
		 ?>
								<div class="entry-meta"> 
									<div class="meta_view"><div class="meta_view_link"><a href="<?php the_permalink() ?>" title="点击阅读全文！点击后您将查看本文的全部内容..."><span id="spn">已有 <?php if(function_exists('the_views')) { the_views(); } ?> 人阅读</span><script type="text/javascript">strBatchView+=",";</script></a></div></div>
							<span class="meta_comment"><?php comments_popup_link('发现&nbsp;0 个古生物抵达新大陆 &#187;', '发现&nbsp;1 个古生物抵达新大陆 &#187;', '发现&nbsp;% 个古生物抵达新大陆 &#187;'); ?></span> 
								
									<!--a href="javascript:void(0);" onclick="alert('824')">支持</a--> 
									<div class="meta_tags">开荒日期：<span>纪元<?php the_time("y年m月d日"); ?></span>  |  关键字：<?php the_tags(' ' , ' , ' , ' '); ?></div> 
								</div> 
							</div> 
						</div><!--entry--> 
					<?php endwhile; ?>

										<!-- google_ad_section_end --> 
					<div class="pagenavi"> 
<span class="pagenavi_l"></span><span class="pagenavi_c"><span class="pages">新鲜热辣的文章</span>
<?php if($pagenavnum=='default'){
		if(function_exists('wp_pagenavi')){wp_pagenavi();}else{?>
		<section class="alignleft"><?php next_posts_link('&laquo; Older Entries');?></section>
    <section class="alignright"><?php previous_posts_link('Newer Entries &raquo;');?></section>
    <section class="clear"></section> 
	<?php }
	}else{pagenavidown();}?>
</span><span class="pagenavi_r"></span></div> 
			</div><!--postlist--> 
<?php get_sidebar(); ?>
	</div><!--section_post--> 
		
 <div class="clear"></div>
	<div id="bottom_ad"><ul> <!-- BAIDU AD -->
	<li></li>
		</ul>
	</div><!--ipc_latest_post_begin-->
	<div class="clear"></div>
	<?php get_footer(); ?>