<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<div id="loading" style="position:fixed !important;position:absolute;top:30px; left:50%;height:100%;"><img src="<?php bloginfo('template_directory'); ?>/images/loading.gif" /></div>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="wumiiVerification" content="1675a5b7-045e-46cc-934d-220011a840dd" />
<title><?php if (is_single() || is_page() || is_archive()) {?><?php wp_title('',true); ?> | <?php } bloginfo('name'); ?> - <?php if( $paged == '') $thispageis= ''; else $thispageis = '第' .$paged. '页'; echo $thispageis; ?> </title>	
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.js" ></script>
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="icon" href="favicon.ico" type="image/x-icon" /> 
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" />
<?php if (function_exists('wp_enqueue_script') && function_exists('is_singular')) : ?>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php endif; ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/top-ads.js"></script>
<script type="text/javascript">$(document).ready( function() {$("#news").newsTicker(); } );</script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/ips.js" ></script>
 <?php if (get_option('world_if_showlazy') == '1') { ?>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/lazyload.js"></script>
<script type="text/javascript">
	$(function() {          
    	$(".entry img").lazyload({
        	placeholder:"<?php bloginfo('template_url'); ?>/images/image-loading.gif",
            effect:"fadeIn"
          });
    	});
</script>
<?php } else { ?>
<?php } ?>
<?php wp_head(); ?>
</head> 
<body> 
<div id="main"> 
	<div id="header"> 
		<div id="logo"><h1><a id="gohome" href="<?php echo get_option('home') ?>"><span style="display:none"><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?></span></a></h1></div> 
		<div id="header_r"> 
		
			<div id="header_gg_search"> 
					<?php include (TEMPLATEPATH . '/searchform.php'); ?>
			</div> 
			
		</div> <!--  #header_r  -->
	</div><!--  #header --> 
	<div class="clear"></div> 
	<div class="nav"><ul> 
<li class="<?php if ( is_home('') ) { ?>nav_home nav_sub page_item ishome<?php } else { ?>nav_home nav_sub page_item<?php } ?>"><a href="<?php echo get_option('home') ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><span>首页</span></a>
			<div id="nav_home_div" class="nav_sub_div r_div">
			<div class="r_t_arr"><b class="r_tl"></b><b class="r_tc"></b><b class="r_tr"></b></div>
			<div class="r_c">


			</div>
			<div class="r_b"><b class="r_bl"></b><b class="r_bc"></b><b class="r_br"></b>
			</div>
			</div>
	</li>
	<li class="<?php if ( is_page('random') ) { ?>page_item page-item-401 current_page_item<?php } else { ?>page_item<?php } ?>"><a href="<?php echo get_option('home') ?>?random" title="随便看看"><span>随便看看</span></a></li>


</ul>

</div> 

