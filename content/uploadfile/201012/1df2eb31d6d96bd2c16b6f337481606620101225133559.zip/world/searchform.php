	<form style="margin:0;padding:0"  action="<?php echo get_option('home') ?>/search" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="003529112488200635197:qtksxypmo9u" />
    <input type="hidden" name="cof" value="FORID:11" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" style="background:#fff;border:1px solid #ccc;border-bottom-color:#999;border-right-color:#999;color:#000;width:200px;height:21px" size="28" />
    <input type="submit" name="sa" style="display:-moz-inline-box;border-bottom:solid 2px #e7e7e7;border-right:solid 2px #e7e7e7;display:inline-block;background:#eee;border:solid 1px;border-color:#ccc #999 #999 #ccc;height:24px;" value="搜索" />
	</div>
</form>
<script type="text/javascript" src="http://www.google.com/cse/brand?form=cse-search-box&lang=zh-Hans"></script>
