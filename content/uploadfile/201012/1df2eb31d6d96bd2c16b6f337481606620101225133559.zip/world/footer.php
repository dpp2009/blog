<script language="JavaScript">
$(document).ready(function() {  
	var origText="";
	$('.entry-title a').click(function(){
			$(this).text('稍等下，我正在很用力地加载文章...');
	});
});  
</script> 
</div><!-- #main--> 
	<div style="clear:both"></div> 
	<div id="footer"> 
<div id="ft_contain"> 
	<div id="ft_1">Contact<ul>
<li><a target="_blank" href="<?php echo home_url( '/' ) ?>">关于本站</a></li>
<li><a target="_blank" href="<?php echo home_url( '/' ) ?>">联系站长</a></li>
</ul></div> 

	<div id="ft_2">Navigation<ul>
<li><a target="_blank" href="<?php echo home_url( '/' ) ?>">站内搜索</a></li>
<li><a target="_blank" href="http://<?php echo home_url( '/' ) ?>archives">文章分类</a></li>
<li><a target="_blank" href="http://<?php echo home_url( '/' ) ?>sitemap.xml">站点地图</a></li>
</ul></div> 

	<div id="ft_3">Links<ul>

</ul></div> 

	<div id="ft_4">Unknow<ul><li><a target="_blank" href="/">等待添加</a></li>
<li><a target="_blank" href="/">等待添加</a></li><li><a target="_blank" href="/">等待添加</a></li>
<li><a target="_blank" href="/">等待添加</a></li>
</ul></div> 

	<div id="ft_5"><br /><p><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>：佛教认为脱离尘世烦恼、取得正果之处。虽然我不是信佛之人，但是我还是希望我的人生能够到达脱离尘世烦恼，取得正果之处！</p><p><br/>本站持续修改完善中，如遇不便还请谅解....</p>
</div> 
</div> 

<div class="ft_info"> 
		Copyright <?php echo comicpress_copyright(); ?> 本站归属于 <a rel="nofollow" href="<?php echo home_url( '/' ) ?>"><?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>™</a>  所有   |
</div>  <script type="text/javascript" async="" src="<?php echo home_url( '/' ) ?>wp-content/themes/world/js/ga.js"></script>
	<div style="display:none"><?php if (get_option('world_tongji')) { ?>   <?php echo get_option('world_tongji'); ?>    <?php } ?></div>
	<!-- 查询次数：| 耗时：<?php timer_stop(1); ?>	 --> 
</div><!-- #footer --> 
 </body> 
 <script>document.write('<style>#loading{display:none}</style>');</script> 
</html> 