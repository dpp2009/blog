<div id="hot_tab"> 
								
									<div class="hot_tab_control"> 
										<ul><li><a id="hot_tab_ctl_l"></a></li>

<li><a id="hot_tab_year_view">年度热门</a></li>
<li><a id="hot_tab_month_view">月度热门</a></li>
<li><a id="hot_tab_new">新文章</a></li>
<li><a class="current_tab" id="hot_tab_rnd">别人正在看</a></li>
<li><a id="hot_tab_comment">新留言</a></li>
<li><a id="hot_tab_month">月度热评</a></li>
<li><a id="hot_tab_year">年度热评</a></li>
<li><a id="hot_tab_ctl_r"></a></li>

</ul>
									</div> 
										<div id="hot_tab_list"><?php 
					$randposts = $wpdb->get_results('SELECT p.ID, p.post_title, rand()*p1.id AS o_id FROM ' . 
$wpdb->posts . ' AS p JOIN ( SELECT MAX(ID) AS id FROM ' 
. $wpdb->posts . ' WHERE post_type="post" AND post_status="publish") AS p1 WHERE p.post_type="post"  
AND p.post_status="publish" ORDER BY o_id LIMIT 8'); 
 
$output = $pre_HTML;
$i=1;

foreach($randposts as $randpost) 
{                    
echo('<ul><li><span class="tabNum">'.$i.'</span><a href="' . get_permalink($randpost->ID) 
. '">' 
. $randpost->post_title . '</a></li></ul>'); 
$i++;  
             }
			 
$output .= $post_HTML;
echo $output;
wp_reset_query();?></div> </div> <!--  #hot_tab--> 