	<?php get_header(); ?>
	<?php include (TEMPLATEPATH . '/headtop.php'); ?>
	<div id="container"> 
		<div id="content"> 
 			<div class="page-title">正在显示 <span>[ <?php single_cat_title(); ?> ]</span> 分类下的文章</div> 
						<div class="pagenavi"> 
<span class="pagenavi_l"></span><span class="pagenavi_c"><span class="pages"><?php single_cat_title(); ?>分类：</span><?php if($pagenavnum=='default'){
		if(function_exists('wp_pagenavi')){wp_pagenavi();}else{?>
		<section class="alignleft"><?php next_posts_link('&laquo; Older Entries');?></section>
    <section class="alignright"><?php previous_posts_link('Newer Entries &raquo;');?></section>
    <section class="clear"></section> 
	<?php }
	}else{pagenavitop();}?></span><span class="pagenavi_r"></span></div> 
 
 		<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
			<div id="post" class="entry"> 
				<h3 class="entry-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3> 
				<div class="entry-date"><abbr class="published" title="<?php the_time("Y-m-j G:h:sO"); ?>">[纪元<?php the_time("y年m月j日"); ?>]</abbr></div> 
				<div class="entry-content"> 
					<div class="entry-banner"><?php
$soContent = $post->post_content;
$soImages = '~<img [^\>]*\ />~';
preg_match_all( $soImages, $soContent, $thePics );
$allPics = count($thePics[0]);
if( $allPics > 0 ){
echo $thePics[0][0];
}
else {
echo '';//<img src="/plus/default.gif" border="0" />
}
?></div> <?php 
 if(has_excerpt()) the_excerpt();
 else
         echo mb_strimwidth(strip_tags($post->post_content),0,500,'……');
		 ?>
				</div> 
				<div class="entry-meta"> 
										<span id="spn">超过 <?php if(function_exists('the_views')) { the_views(); } ?> 人围观</span><script type="text/javascript">strBatchView+=",";</script>					<span class="meta-sep">|</span> 
					<span class="tag-links">关键字：<?php the_tags(' ' , ' , ' , ' '); ?></span> <span class="meta-sep">|</span>					<span class="comments-link"><?php comments_popup_link('暂无评论', '评论数：(1)', '评论数：(% )'); ?></span> 
				</div> 
			</div><!-- .post --> 
 	<?php endwhile; ?>
						   <?php endif; ?>	 
		<div class="page-title">正在显示 <span>[  <?php single_cat_title(); ?> ]</span> 分类下的文章</div> 
		<div class="pagenavi"> 
<span class="pagenavi_l"></span><span class="pagenavi_c"><span class="pages"> <?php single_cat_title(); ?>分类：</span><?php if($pagenavnum=='default'){
		if(function_exists('wp_pagenavi')){wp_pagenavi();}else{?>
		<section class="alignleft"><?php next_posts_link('&laquo; Older Entries');?></section>
    <section class="alignright"><?php previous_posts_link('Newer Entries &raquo;');?></section>
    <section class="clear"></section> 
	<?php }
	}else{pagenavidown();}?></span><span class="pagenavi_r"></span></div> 
		</div><!-- #content --> 
	</div><!-- #container --> 
	<?php include (TEMPLATEPATH . '/sidebar_2.php'); ?>
		<?php get_footer(); ?>