<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/comment.min.css" />
<?php // Do not delete these lines
	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');
	if (!empty($post->post_password)) { // if there's a password
		if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
			?>
			<p class="nocomments">This post is password protected. Enter the password to view comments.</p>
			<?php
			return;
		}
	}

	/* This variable is for alternating comment background */
	/*$oddcomment = '';*/
?>
<div id="comments">
<div id="cmtswitcher">
					<a id="commenttab" class="curtab" href="javascript:void(0);">
					<?php comments_number('评论 (0)', '评论 (1)', '评论 (%)' );?></A>
				<div class="clear"></DIV>
	</DIV>
	<div id="comment_div">
	<div id="comment_head"><?php comments_number('各位请注意，目前发现<span> 0 位寻荒者</span> 在附近海域漂移！ ', '各位请注意，目前发现<span> 1 位寻荒者</span> 在附近海域漂移！', '各位请注意，目前发现<span> % 位寻荒者</span> 在附近海域漂移！' );?></div>
<?php if ($comments) : ?>
				<?php
	// 如果用户在后台选择要显示评论分页
	if (get_option('page_comments')) {
		// 获取评论分页的 HTML
		$comment_pages = paginate_comments_links('echo=0');
		// 如果评论分页的 HTML 不为空, 显示上一页和下一页的链接
		if ($comment_pages) {
?>
	<div class="commentnavi">
	<span class="commentnavi-icon"></span>
				<span class="commentpager">
		<?php echo $comment_pages; ?>
	</span></div><?php
		}
	}
?>
<ul id="thecomments" class="commentlist">
	<?php wp_list_comments('type=comment&callback=blog_comment&end-callback=blog_end_comment'); ?>
	</ul>
		<?php
	// 如果用户在后台选择要显示评论分页
	if (get_option('page_comments')) {
		// 获取评论分页的 HTML
		$comment_pages = paginate_comments_links('echo=0');
		// 如果评论分页的 HTML 不为空, 显示上一页和下一页的链接
		if ($comment_pages) {
?>
	<div class="commentnavi">
	<span class="commentnavi-icon"></span>
				<span class="commentpager">
		<?php echo $comment_pages; ?>
	</span></div><?php
		}
	}
?>
	<?php else : // this is displayed if there are no comments so far ?>
	<?php if ('open' == $post->comment_status) : ?>
		<!-- If comments are open, but there are no comments. -->
	 <?php else : // comments are closed ?>
		<!-- If comments are closed. -->
		<p class="nocomments">报歉!评论已关闭.</p>
	<?php endif; ?>
	<?php endif; ?>
	</div><!-- comment_div END -->
	
	<!-- trackbacks START -->
		<DIV class="clear"></DIV>
	<!-- trackbacks END -->
	<?php if ('open' == $post->comment_status) : ?>
 <div class="clear"></div> 
<div id="comment_foot">开辟每一块荒地都是十分艰辛，请各位无论在哪个岛屿生活一定要安份守已。和睦相处。</div> 
<div id="respond"> 
<div id="respond-head"></div> 
<div id="respond-contain"> 
<div id="cancel-comment-reply"><a rel="nofollow" id="cancel-comment-reply-link" href="#respond" style="display:none;">点击这里取消回复。</a></div> 
<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
	<p><?php print 'You must be'; ?> <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php echo urlencode(get_permalink()); ?>"><?php print 'Logged in'; ?></a> <?php print 'to post comment'; ?>.</p>
    <?php else : ?>
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="POST" id="commentform" onSubmit="return(checkComment())"> 

		<?php if ( $user_ID ) : ?>
<p><?php print '登录者：'; ?> <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>&nbsp;&nbsp;<a href="<?php echo wp_logout_url(get_permalink()); ?>" title="退出"><?php print '[ 退出 ]'; ?></a></p>
<?php else : ?>	<div class="comment-input">
<label for="author"><?php if ($req) echo "你的大名 (*必填) ："; ?></label><br/> 
			<input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" aria-required='true' /> 
			<br/> 
			<label for="email">E-Mail  <?php if ($req) echo " (*必须)"; ?>：</label><br/>
       
			<input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" aria-required='true' /> 
			<br/> 
			<label for="url">你的网站 (可选填)：</label><br/> 
			<input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" /> 
			</div> 
			 <?php endif; ?>
			<div id="comment-txt-input">评论内容 (*必填)：<br/> 
			<textarea class="comment-area" name="comment" id="comment" cols="100%" rows="14" tabindex="4"></textarea> 
			</div> 
			
			<div class="comment-set-avatar"><div id="set-avatar"><a target="_blank" href="http://www.gravatar.com"><img class="fanfou_avatar"  src="http://0.gravatar.com/avatar/819d3ebd19a7f8abc359187f339f7e96?s=62&d=http%3A%2F%2Fbianworld.com%2Fwp-content%2Fthemes%2Fblue%2Fimages%2FFavatar.png%3Fs%3D34&r=G" /></a><span style="display:none">GRAVATAR头像</span></a></div><a target="_blank" href="http://www.gravatar.com">设置你的头像</a></div> 
						<div class="comment_btn">(Ctrl + Enter 快速提交)&nbsp;&nbsp;&nbsp;<input name="submit" type="submit" id="submit" tabindex="5" value="留下我的足迹..." /></div> 
 <?php comment_id_fields(); ?>
 <?php do_action('comment_form', $post->ID); ?>
			</form>
</div><!--respond-contain --> 
   <?php endif; // If registration required and not logged in ?>
<div id="respond-foot"></div> 
 
<script type="text/javascript">	
//<![CDATA[
document.getElementById('comment').onkeydown = function (moz_ev)
{
	var ev = null;
	if (window.event){
		ev = window.event;
	}else{
		ev = moz_ev;
	}
	if (ev != null && ev.ctrlKey && ev.keyCode == 13)
	{
		document.getElementById('submit').click();
	}
}
function checkComment(){
	cm=document.getElementById('comment').value;
	if(document.getElementById('author').value=="" ||document.getElementById('email').value=="" || cm==""){
		alert("嘿嘿，你好像还有东西没写耶，我不给你发！");
		return false;
	}
	re =/[\u4E00-\u9FA5]{1,}/ig;
	r = cm.match(re);
	if(r==null || r.length<=0){
		alert("为了促进世界和平与社会和谐，你至少要写一个中文字的说……");
		return false;
	}
	return true;
}
//]]>
</script>   
</div> <!--#respond--> 
<?php endif; // if you delete this the sky will fall on your head ?>
</div><!-- #comments -->   