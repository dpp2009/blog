$(function() {
	//搜索框
	var keyWord = $("input#s");
	if (keyWord.val().length >= 1 ) keyWord.prev("label").hide();
	keyWord.focus(function(){ keyWord.prev("label").hide(); })
	keyWord.blur(function(){
		if (keyWord.val() == "") {
			keyWord.val("");
			keyWord.prev("label").show();
		}
	})

	//主菜单下拉
	$("#nav li").hover(
		function() {
			$(this).children("ul").slideDown(100);
		},
		function() {
			$(this).children("ul").slideUp(100);
		}
	);
	$("#nav li a").hover(
		function() {
			$(this).animate({opacity:0.3}, 0);
			$(this).animate({opacity:1}, 300);
		},
		function(){}
	);

	//赞助我
	$("#sponsor").html($("#sponsor-me").attr("title"));
	$("#sponsor-me").attr("title","");
	$("#sponsor-me").hover(
		function() {
			$("#sponsor").slideDown(200);
			$("#sponsor").attr("style","display:block;");//这一行是为了解决 jQuery IE8 bug
		},
		function() { $("#sponsor").fadeOut(200); }
	);

	//列表隔行换色
	$(".list li:odd").addClass("odd");

	//初始化选项卡
	$("#choice ul:first").idTabs();
	$("#side-cmt ul:first").idTabs();
	$("#column-nav ul:first").idTabs();

	//鼠标经过tips效果
	$("#container a").mouseover(function(tips){
		this.tipsTxt = this.title;
		this.tipsTxt = (this.tipsTxt.length>50?this.tipsTxt.toString().substring(0,50)+"...":this.tipsTxt);
			if (this.tipsTxt){
				this.tipsUrl = this.href;
				this.title = "";
				var tips = "<div id='tips'><p>"+this.tipsTxt+"</p><p><em>"+this.tipsUrl+"</em>"+"</p></div>";
				$('body').append(tips);
				$('#tips').css({"opacity":"0.8"})
			}
		}).mouseout(function(){
			this.title=this.tipsTxt;
			$('#tips').remove();
		}).mousemove(function(tip){ $('#tips').css({"top":(tip.pageY+22)+"px","left":(tip.pageX-10)+"px"});
	});
	//鼠标经过tips效果结束

	//新窗口打开
	$(function() { $("a[rel*='external']").attr("target","_blank") });

	//滑动到顶部
	$('#to-top').click(function() { $('html,body,#wrap').animate({ scrollTop: 0 }, 1000); });

});


//闪动联系我
function showContact() {
	for (i = 0; i<5; i++) {
		$("#contact").fadeOut(200);
		$("#contact").fadeIn(100);
	}
}