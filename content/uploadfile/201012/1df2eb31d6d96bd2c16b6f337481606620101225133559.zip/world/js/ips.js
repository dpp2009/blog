//nav sub menu
var isNavHover=false;

//focus img player
var t = n = 0;
var count = 0;

function copy_code(text) {
  if (window.clipboardData) {
    window.clipboardData.setData("Text", text)
	alert("已经成功复制到剪贴板！");
  } else {
	var x=prompt('你的浏览器可能不能正常复制\n请你手动进行：',text);
  }
  //return false;
}
function shareto(id){
	var url=encodeURIComponent(document.location.href);
	var title=encodeURIComponent(document.title);
	if(id=="fav"){
		addBookmark(document.title);
		return;
	}else if(id=="qzone"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'QZone', 1]);
		window.open('http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='+url);
		return;
	}else if(id=="twitter"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'Twitter', 1]);
		window.open('http://twitter.com/home?status='+title+encodeURIComponent(' ')+url,'_blank');
		return;
	}else if(id=="sina"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'SinaT', 1]);
		//window.open('http://v.t.sina.com.cn/share/share.php?title='+title+'&url='+url+'&source=bookmark','_blank');
		window.open("http://v.t.sina.com.cn/share/share.php?url="+url+"&appkey=610475664&title="+title+"&pic=","_blank","width=615,height=505");
		return;
	}else if(id=="qqshuqian"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'QQShuqian', 1]);
		window.open('http://shuqian.qq.com/post?from=3&jumpback=2&noui=1&uri='+url+'&title='+title,'_blank','width=930,height=570,left=50,top=50,toolbar=no,menubar=no,location=no,scrollbars=yes,status=yes,resizable=yes');
		return;
	}else if(id=="baidu"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'Baidu', 1]);
		window.open('http://cang.baidu.com/do/add?it='+title+'&iu='+url+'&fr=ien#nw=1','_blank','scrollbars=no,width=600,height=450,left=75,top=20,status=no,resizable=yes');
		return;
	}else if(id=="googlebuzz"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'GoogleBuzz', 1]);
		//window.open('http://www.google.com/buzz/post?url='+url+'&imageurl=');
		window.open('http://www.google.com/buzz/post?url='+url,'_blank');
		return;
	}else if(id=="douban"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'Douban', 1]);
		var d=document,e=encodeURIComponent,s1=window.getSelection,s2=d.getSelection,s3=d.selection,s=s1?s1():s2?s2():s3?s3.createRange().text:'',r='http://www.douban.com/recommend/?url='+e(d.location.href)+'&title='+e(d.title)+'&sel='+e(s)+'&v=1',x=function(){if(!window.open(r,'douban','toolbar=0,resizable=1,scrollbars=yes,status=1,width=450,height=330'))location.href=r+'&r=1'};
		if(/Firefox/.test(navigator.userAgent)){setTimeout(x,0)}else{x()}
		return;
	}else if(id=="renren"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'RenRen', 1]);
		window.open('http://www.connect.renren.com/share/sharer?url='+url+'&title='+title,'_blank');
		return;
	}else if(id=="xianguo"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'XianGuo', 1]);
		window.open('http://xianguo.com/service/submitdigg/?link='+url+'&title='+title,'_blank');
		return;
	}else if(id=="digu"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'Digu', 1]);
		window.open('http://www.diguff.com/diguShare/bookMark_FF.jsp?title='+title+'&url='+url,'_blank','width=580,height=310');
		return;
	}else if(id=="mail"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'Mail', 1]);
		window.open('mailto:?subject='+title+'&body='+encodeURIComponent('这是我看到了一篇很不错的文章，分享给你看看！\r\n\r\n')+title+encodeURIComponent('\r\n')+url);
		return;
	}else if(id=="tqq"){
		_gaq.push(['_trackEvent', 'SocialShare', 'Share', 'TQQ', 1]);
		window.open('http://v.t.qq.com/share/share.php?title='+title+'&site=http://www.iplaysoft.com/&pic=&url='+url,'_blank');
		return;
	}
}

function ShareButtons(){
	document.write('<div class="social_share">');
	document.write('<a class="sharebutton" id="share_qzone" href="javascript:shareto(\'qzone\');" title="分享到QQ空间"></a>');
	document.write('<a class="sharebutton" id="share_tqq" href="javascript:shareto(\'tqq\');" title="分享到 QQ 腾讯微博"></a>');
	document.write('<a class="sharebutton" id="share_sina" href="javascript:shareto(\'sina\');" title="分享到新浪微博"></a>');
	document.write('<a class="sharebutton" id="share_qqshuqian" href="javascript:shareto(\'qqshuqian\');" title="收藏到QQ书签"></a>');
	document.write('<a class="sharebutton" id="share_twitter" href="javascript:shareto(\'twitter\');" title="分享到Twitter"></a>');
	document.write('<a class="sharebutton" id="share_renren" href="javascript:shareto(\'renren\');" title="分享到人人网"></a>');
	document.write('<a class="sharebutton" id="share_baidu" href="javascript:shareto(\'baidu\');" title="收藏到 - 百度搜藏"></a>');
	document.write('<a class="sharebutton" id="share_googlebuzz" href="javascript:shareto(\'googlebuzz\');" title="分享到 Google Buzz"></a>');
	document.write('<a class="sharebutton" id="share_douban" href="javascript:shareto(\'douban\');" title="分享到豆瓣"></a>');
	document.write('<a class="sharebutton" id="share_xianguo" href="javascript:shareto(\'xianguo\');" title="分享到鲜果网"></a>');
	document.write('<a class="sharebutton" id="share_digu" href="javascript:shareto(\'digu\');" title="分享到嘀咕"></a>');
	//document.write('<a class="sharebutton" id="share_mail" href="javascript:shareto(\'mail\');" title="发送邮件分享给朋友"></a>');
	document.write('</div>');
}











function addBookmark(title){
    var url = parent.location.href;
    if (window.sidebar) { // Mozilla Firefox Bookmark
        window.sidebar.addPanel(title, url,"");
    } else if(document.all) { // IE Favorite
        window.external.AddFavorite( url, title);
    } else if(window.opera) { // Opera 7+
        return false; // do nothing
    } else { 
         alert('请按 Ctrl + D 为Chrome浏览器添加书签!');
    }
}


$(document).ready(function(){
//nav sub menu
$('.nav_sub,.nav_sub_div').hover(
	function() {
		if(isNavHover==false ){$('.nav_sub_div').hide();}//fadeOut(500);}
		isNavHover=true;
		$(this).children('.nav_sub_div').fadeIn(500);
	},
	function() {
		setTimeout(
			function () {
			if(!isNavHover){
				$('.nav_sub_div').hide();//fadeOut(500);
			}}
		,750);
		isNavHover=false;
	}
);

$('.comment_body').hover(
	function() {
		$(this).find('.commentmetadata').stop(true,true).show();
	},
	function() {
		$(this).find('.commentmetadata').stop(true,true).hide();
	}
);

$('.entry').hover(
	function() {
		$(this).find('.meta_view_link').stop(true,true).fadeIn();
	},
	function() {
		$(this).find('.meta_view_link').stop(true,true).fadeOut();
	}
);

//1st post show
$('#section_show_post').hover(
 function() {
 $("#post_show_link_l,#post_show_link_r").stop(true,true);
 $("#post_show_link_l,#post_show_link_r").fadeIn();
 },
 function() {
 $("#post_show_link_l,#post_show_link_r").stop(true,true);
 $("#post_show_link_l,#post_show_link_r").fadeOut();
 }
); 

$("#post_show_link_l,#post_show_link_r").click(function(){
	// if($(this).attr("rel")=="0")return;
	 $.ajax({
	   type: "POST",
	   url: "/plus/api/ajax_getposts.php",
	   data: "type=post_show&post_show_id="+$(this).attr('rel'),
	   error: function (XMLHttpRequest, textStatus, errorThrown) {
			alert ("通信失败...");
		},
		beforeSend:function(){
		 $("#show_post_entry").html('<div id="post_show_loading"><img src="/plus/images/loading.gif" /><br/><br/>请您稍等一下...，这就去给你找文章去...</div>');
		},
	   success: function(msg){
		 $("#show_post_entry").hide();
		 var str=msg.split('songlecn');
		 $("#show_post_entry").html(str[0]);
		 $("#post_show_link_l").attr("rel",str[1]);
		 $("#post_show_link_r").attr("rel",str[2]);
		 $("#show_post_entry").fadeIn();
	   }
	 });
});

$("#hot_tab_ctl_l,#hot_tab_ctl_r").click(function(){
alert("Sorry..  这个真没有，别再点啦……");
});

//Hot Tab Index
var isTabRndHover;
var isTabDivHover;
isTabRndHover=true;isTabDivHover=false;
$("#hot_tab_comment,#hot_tab_new,#hot_tab_most_comment,#hot_tab_rnd,#hot_tab_month,#hot_tab_year,#hot_tab_month_view,#hot_tab_year_view").click(function(){
	 $("#hot_tab_list").html('<div class="hot_tab_loading"><img src="/plus/images/loading.gif" /></div>');
	 $(".current_tab").removeClass("current_tab");
	 $(this).addClass("current_tab");
	 $("#hot_tab_list").load("/plus/api/ajax_getposts.php",{"type":$(this).attr("id")});
	 return false; 
});
$("#hot_tab_list").mouseover(function(){isTabDivHover=true;})
$("#hot_tab_list").mouseout(function(){isTabDivHover=false;})

});