<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<div id="loading" style="position:fixed !important;position:absolute;top:30px; left:50%;height:100%;"><img src="http://bianworld.com/wp-content/themes/world/images/loading.gif" /></div>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php if (is_single() || is_page() || is_archive()) {?><?php wp_title('',true); ?> | <?php } bloginfo('name'); ?> - <?php if( $paged == '') $thispageis= ''; else $thispageis = '第' .$paged. '页'; echo $thispageis; ?> </title>	
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<script type="text/javascript" src="http://bianworld.com/wp-content/themes/world/js/jquery.js" ></script>
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="icon" href="favicon.ico" type="image/x-icon" /> 
<link rel="shortcut icon" href="http://bianworld.com/wp-content/themes/world/image