<html>	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo '页面跳转 '; ?></title>
<head><?php $url=$_GET["url"];  
  echo   "<script   language='Javascript'>";
  echo   "location='$url';";   
  echo   "</script>";   
?></head>
<body>
页面跳转中... 请稍等...
</body>
</html>